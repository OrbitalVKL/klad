# Consignes pour Claude (dépôt Klad)

- Langue : français, phrases simples, termes techniques expliqués au besoin.
- Méthode : **mode plan puis mode action**. Proposer le plan, attendre la validation, puis développer.
- Référence fonctionnelle : le cahier des charges et le suivi de développement sont tenus **hors du dépôt** par le propriétaire ; il en fournit le contenu utile en début de session. Ne rien supposer qui n'y figure pas.
- Dépôt **public** : aucune donnée personnelle ni secret dans le code, les commits, les tickets, les journaux d'Actions ou les noms de fichiers (noms, banques utilisées, IBAN, montants, clés, identifiants Enable Banking, adresses e-mail). Exemples et tests avec des données fictives uniquement.
- Ne jamais ajouter de fichier `.pem`, `.jks`, `.b64`, `.env` ni de clé ; les secrets passent par les secrets GitHub Actions.
- Le compte GitHub n'est écrit nulle part : il est déduit à la fabrication (`GITHUB_REPOSITORY_OWNER`).
- Formulations financières dans l'interface : pas de montants négatifs affichés ; dire « débit / crédit », « débiteur », ou qui doit combien à qui.
- Avant de pousser : `npm test` doit passer.
- Travail sur une branche + demande de fusion ; `main` déclenche la fabrication de l'APK et du site.
